use std::io::prelude::*;
use std::collections::HashSet;
use std::error::Error;
use rust_htslib::bam;
use rust_htslib::bam::Read;

mod cli;

fn main() {
    let config = cli::Config::new().expect("Error processing command line");
    let ids = build_hash(config.indexfile).expect("Error building index hash");
    filter_bam(ids, config.inputfile, config.outputfile).expect("Error filtering BAM")
}

fn build_hash<R>(reader: R) -> Result<HashSet<Vec<u8>>, Box<dyn Error + 'static>>
    where R: BufRead
{
    let mut ids: HashSet<Vec<u8>> = HashSet::new();
    for l in reader.split(b'\n') {
        let mut line = l?;
        if line.last().unwrap() == &b'\r' {
            line.pop();
        }
        ids.insert(line);
    }
    Ok(ids)
}

fn filter_bam<R>(id_hash: HashSet<Vec<u8>>,
                 mut reader: R,
                 mut writer: bam::Writer) -> Result<(), Box<dyn Error>>
    where R: Read
{
    let mut record = bam::Record::new();
    while let true = reader.read(&mut record)? {
        if id_hash.contains(record.qname()) {
            writer.write(&record)?;
        }
    };
    Ok(())
}
