use std::fs::File;
use std::io::BufReader;
use std::error::Error;
use rust_htslib::bam;
use rust_htslib::bam::Read;
use clap::{App, Arg, ArgMatches, crate_version, crate_authors};

pub struct Config {
    pub indexfile: BufReader<File>,
    pub inputfile: bam::Reader,
    pub outputfile: bam::Writer,
}

impl Config {
    pub fn new() -> Result<Config, Box<dyn Error>> {
        let args = Self::parse_commandline();

        let indexfile_name = args.value_of("indexfile")
            .ok_or("No indexfile supplied")?;
        let compression_level = args.value_of("compression_level")
            .ok_or("No compression level supplied")?
            .parse::<u32>()?;

        let indexfile = BufReader::new(File::open(indexfile_name)?);

        let inputfile = match args.value_of("inputfile") {
            Some(filename) => bam::Reader::from_path(filename)?,
            None => bam::Reader::from_stdin()?,
        };

        let header = bam::Header::from_template(inputfile.header());

        let output_format = if args.is_present("output_sam") {
            bam::Format::SAM
        } else {
            bam::Format::BAM
        };

        let mut outputfile = match args.value_of("outputfile") {
            Some(filename) =>
                bam::Writer::from_path(filename, &header, output_format)?,
            None =>
                bam::Writer::from_stdout(&header, output_format)?,
        };

        outputfile.set_compression_level(bam::CompressionLevel::Level(compression_level))?;

        Ok(Config { indexfile, inputfile, outputfile }
        )
    }

    fn parse_commandline() -> ArgMatches<'static> {
        let app = App::new("bamfilter")
            .version(crate_version!())
            .author(crate_authors!())
            .long_about("\n\
                Filter BAM file by sequence ids (QNAME field)\n\
                =============================================")
            .arg(Arg::with_name("indexfile")
                .short("i")
                .long("indexfile")
                .value_name("FILE")
                .help("File containing sequence ids, one per line")
                .takes_value(true)
                .required(true)
            )
            .arg(Arg::with_name("outputfile")
                .short("o")
                .long("outputfile")
                .value_name("FILE")
                .help("Output BAM/SAM file [default: STDOUT]")
                .takes_value(true)
            )
            .arg(Arg::with_name("output_sam")
                .short("s")
                .long("sam")
                .help("Write output in SAM format")
            )
            .arg(Arg::with_name("compression_level")
                .short("l")
                .long("level")
                .value_name("N")
                .help("BGZF compression level [0..9]")
                .takes_value(true)
                .possible_values(&["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"])
                .default_value("6")
                .hide_possible_values(true)
            )
            .arg(Arg::with_name("inputfile")
                .help("Input BAM file [default: STDIN]")
                .value_name("FILE")
                .index(1)
            );
        app.get_matches()
    }
}
