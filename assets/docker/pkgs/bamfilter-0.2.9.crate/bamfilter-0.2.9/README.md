# bamfilter

A (fast) tool to filter a BAM file by a list of QNAMEs (sequence IDs).

## Usage:

Basic usage:

```bash
bamfilter -i <ids.txt> -o <output.bam> <input.bam>
```

`ids.txt` is a text file containing sequence IDs to be filtered for, one per line.

For more details run:

```bash
bamfilter --help
```
