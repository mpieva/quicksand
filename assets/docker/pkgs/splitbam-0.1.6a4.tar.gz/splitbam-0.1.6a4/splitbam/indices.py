__all__ = ['version', 'p7_indices', 'p5_indices']


import json
from pkg_resources import resource_filename


def maybe_int(i):
    try:
        return int(i)
    except ValueError:
        return i


def swap_keys(d):
    return {v: maybe_int(k) for k, v in d.items()}


indices = resource_filename(__name__, 'data/indices.json')
with open(indices, 'r') as datafile:
    indices = json.load(datafile)

version = indices['version']
p5_indices = swap_keys(indices['p5index'])
p7_indices = swap_keys(indices['p7index'])
