"""Command-line interface for splitbam"""

import operator
from functools import reduce

from ._version import __version__

__all__ = ['get_config']

from argparse import ArgumentParser, RawTextHelpFormatter, FileType
from pathlib import PosixPath as Path


def excluded(config):
    """Calcuate an exclusion bitmask to be applied to flags."""
    ex_map = {'merged': 0x1, 'mapped': 0x4}
    ex_bits = [b for (c, b) in ex_map.items() if getattr(config, c) is True]
    return reduce(operator.__or__, ex_bits, 0)


def get_config():
    """Get configuration.

    Populate the command-line argument parser, and parse command-line flags.

    """
    parser = ArgumentParser(
        description="Split BAM file into many, "
                    "according to readgroup or index combination.",
        formatter_class=RawTextHelpFormatter,
    )

    parser.add_argument(
        '--version', action='version', version=__version__,
        help="display version information and exit"
    )

    mutex_rg = parser.add_mutually_exclusive_group()
    mutex_rg.add_argument(
        '-r', '--by-readgroup', action='store_true', default=True,
        help="write one BAM file for each read group identifier\n"
             "present in BAM file (default)"
    )
    mutex_rg.add_argument(
        '-f', '--by-file', metavar='FILE',
        type=FileType('r', encoding='latin-1'),
        help="read index combinations from tab-separated file\n"
             "- format of file: 'LibID<tab>P7<tab>P5'\n"
             "- ignore read group in BAM file\n"
             "- require perfect index matching"
    )

    parser.add_argument(
        '-l', '--limit', type=int, metavar='N',
        help="split first N sequences only"
    )
    parser.add_argument(
        '--minscore', type=int, metavar='N', default=0,
        help="phred score cutoff for index base quality (default: %(default)s)"
    )
    parser.add_argument(
        '--maxnumber', type=int, metavar='N',
        help="allowed number of index base quality scores below cutoff\n"
             "(default: no limit)"
    )

    mutex_p5_p7 = parser.add_mutually_exclusive_group()
    mutex_p5_p7.add_argument(
        '-5', '--p5only', action='store_true',
        help="split based on p5 index only"
    )
    mutex_p5_p7.add_argument(
        '-7', '--p7only', action='store_true',
        help="split based on p7 index only"
    )

    parser.add_argument(
        '--mapped', action='store_true',
        help="output mapped sequences only"
    )
    parser.add_argument(
        '--merged', action='store_true',
        help="output overlap-merged sequences only"
    )
    parser.add_argument(
        '--minlength', type=int, metavar='N',
        help="minimum sequence length"
    )
    parser.add_argument(
        '--overwrite-rg', action='store_true',
        help="overwrite RG field with entry from input file [*]"
    )
    parser.add_argument(
        '-u', '--unexpected', action='store_true',
        help="write sequences with unexpected index combinations to\n"
             "separate BAM file"
    )
    parser.add_argument(
        '-d', '--outdir', type=Path, metavar='PATH',
        default=Path.cwd(),
        help="directory for output BAM files (default: current)"
    )
    parser.add_argument(
        '-c', '--compression-level', type=int, metavar='N',
        choices=(0, 1, 2, 3, 4, 5, 6, 7, 8, 9), default=6,
        help="compression level for output BAM files [0..9]\n"
             "(default: %(default)s)"
    )
    parser.add_argument(
        '-g', '--ghostfiles', action='store_true',
        help="write empty BAM files for unmatched readgroups\n"
             "in index file (for pipeline use)"
    )
    parser.add_argument(
        '-s', '--stats', action='store_true',
        help="write statistics to STDOUT"
    )
    parser.add_argument(
        'bamfile', type=FileType('rb'),
        help="input BAM file (default: STDIN)"
    )

    parser.epilog = "[*] THESE OPTIONS ARE NOT YET IMPLEMENTED."

    args = parser.parse_args()

    args.by_readgroup = not args.by_file
    args.exclude_mask = excluded(args)

    if args.outdir is not None:
        if not args.outdir.exists():
            parser.error(f"output directory '{args.outdir}' does not exist")
        if not args.outdir.is_dir():
            parser.error(f"'{args.outdir}' is not a directory")

    if args.minscore and args.maxnumber is None:
        parser.error("--minscore requires --maxnumber")

    for flag in ['p5only', 'p7only', 'ghostfiles']:
        if getattr(args, flag) and args.by_file is None:
            parser.error(f"--{flag} requires --by-file")

    return args
