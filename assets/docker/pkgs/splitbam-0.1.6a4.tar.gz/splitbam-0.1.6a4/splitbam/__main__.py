"""Split BAM file into many, according to readgroup or index combination.

"""

import atexit
from collections import namedtuple, Counter

from pysam import AlignmentFile, AlignedSegment

from .cli import *
from .indices import *

SeqPair = namedtuple('SeqPair', ['p7', 'p5'], defaults=(None, None))
IdxPair = namedtuple('IdxPair', ['p7', 'p5'], defaults=(None, None))

# Variables in the module scope
CFG = None
LIBRARY_IDS = {}
SPLIT_FILES = {}


class IndexPair:

    def __init__(self, p5_seq=None, p7_seq=None):
        self.p5_seq = p5_seq
        self.p7_seq = p7_seq
        self._p5 = None
        self._p7 = None
        self._readgroup = None
        
    @property
    def p5(self):
        if self._p5 is None:
            self._p5 = p5_indices.get(self.p5_seq, '-')
        return self._p5
    
    @property
    def p7(self):
        if self._p7 is None:
            self._p7 = p7_indices.get(self.p7_seq, '-')
        return self._p7

    @property
    def sequencepair(self):
        return SeqPair(p5=self.p5_seq, p7=self.p7_seq)

    @property
    def indexpair(self):
        return IdxPair(p5=self.p5, p7=self.p7)

    @property
    def readgroup(self):
        if self._readgroup is None:
            if '-' in self.indexpair:
                self._readgroup = 'unknown'
            else:
                self._readgroup = LIBRARY_IDS.get(self.indexpair, 'unexpected')
        return self._readgroup

    def __eq__(self, other):
        return self.indexpair == other.indexpair

    def __hash__(self):
        return hash(self.indexpair)

    def __str__(self):
        return '\t'.join(
            str(e) for e in
            [self.p7_seq, self.p7, self.p5_seq, self.p5, self.readgroup]
        )

class FilterException(Exception):
    """Raised by a GatedFilter when it can't process further records."""
    pass


class GatedFilter:
    """Gated Filter

    A callable object that serves as a predicate.
    Has an attribute to indicate whether it is active.

    """
    def __init__(self, active_test):
        self.active = bool(active_test)

    def __call__(self, count: int, record: AlignedSegment) -> bool:
        return self.filter(count, record)

    @property
    def inactive(self) -> bool:
        return not self.active

    def filter(self, count: int, record: AlignedSegment) -> bool:
        """The filter method -- override in sublasses."""
        return True

    def gfilter(self, *args, **kwargs):
        """The gated filter -- only filter when active."""
        if self.inactive:
            return True
        else:
            return self.filter(*args, **kwargs)

    @classmethod
    def stop_on_fail(cls, fn):
        """Decorator for filter()/gfilter() - stop processing on first fail"""
        def wrapper(self, *args, **kwargs):
            result = fn(self, *args, **kwargs)
            if not result:
                raise FilterException
            return result
        return wrapper


class FilterLimit(GatedFilter):
    """A counter-based filter to implement --limit

    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._read1_counter = 0

    @GatedFilter.stop_on_fail
    def filter(self, count: int, record: AlignedSegment) -> bool:
        if self._read1_counter < CFG.limit:
            if not record.is_read2:
                self._read1_counter += 1
            return True
        else:
            return False


class FilterQuality(GatedFilter):
    """A quality filter to implement --minscore and --maxnumber

    """
    def filter(self, count: int, record: AlignedSegment) -> bool:
        qual = record.get_tag('YI') + record.get_tag('YJ')
        bad = sum(1 for c in qual if ord(c) - 34 < CFG.minscore)
        return bad <= CFG.maxnumber


class FilterLength(GatedFilter):
    """A length-based filter to implement --minlength

    """
    def filter(self, count: int, record: AlignedSegment) -> bool:
        return record.query_length >= CFG.minlength


class FilterFlags(GatedFilter):
    """Filter based on combinations of the 'flags' field

    """
    def filter(self, count: int, record: AlignedSegment) -> bool:
        return not (record.flag & CFG.exclude_mask)


def apply_filters(filterlist, iterable):
    """Apply a list of filters to an iterable.

    The iterable is enumerated, and both the count and item are
    passed to the filter callable.

    - If any single filter fails, short-circuit.
    - If all pass, yield item.

    """
    for count, item in enumerate(iterable):
        for f in filterlist:
            try:
                if not f(count, item):
                    break
            except FilterException:
                return
        else:
            yield item


def parse_index(indexfile):
    """Parse TSV file with indices."""

    def tsv_iter():
        for line in indexfile:
            if not line.startswith('#'):
                lib_id, p7, p5 = line.split('\t')[:3]
                yield IdxPair(int(p7), int(p5)), lib_id

    index_dict = dict(tsv_iter())
    indexfile.close()
    return index_dict


def get_readgroup_by_tag(seq):
    """Determine the readgroup from a sequence (alignment entry) tag."""
    try:
        return seq.get_tag('RG')
    except KeyError:
        return 'unknown'


def get_indexpair(seq):
    """Determine readgroup for a sequence (alignment entry)."""
    if CFG.p5only:
        return IndexPair(p5_seq=seq.get_tag('XJ'))
    elif CFG.p7only:
        return IndexPair(p7_seq=seq.get_tag('XI'))
    else:
        return IndexPair(
            p7_seq=seq.get_tag('XI'),
            p5_seq=seq.get_tag('XJ')
        )


def create_bamfile(rg, hdr):
    bamfile = AlignmentFile(CFG.outdir / f"{rg}.bam", 'wb', header=hdr)
    bamfile.add_hts_options([f"level={CFG.compression_level}".encode('UTF-8')])
    return bamfile


def writer(seq, rg, hdr):
    """Write a sequence (alignment entry) to matching output file."""

    # When filtering by embedded RG, 'unknown.bam' is always written
    # (if there are unknown RGs). When filtering by a file of indices,
    # 'unexpected.bam' is only written if the --unexpected flag was
    # given. This mirrors the behaviour of splitBAM.pl
    if rg == 'unknown' and CFG.by_file:
        return
    if rg == 'unexpected' and not CFG.unexpected:
        return

    # Can't use setdefault() here, since both its arguments will be
    # evaluated eagerly, causing file truncation.
    try:
        outfile = SPLIT_FILES[rg]
    except KeyError:
        outfile = create_bamfile(rg, hdr)
        SPLIT_FILES[rg] = outfile
    outfile.write(seq)


@atexit.register
def cleanup_bamfiles():
    """Clean up and terminate opened output BAM files on exit."""
    for out_bamfile in SPLIT_FILES.values():
        out_bamfile.close()


def create_ghost_files(bam_header):
    """Create bamfiles for unmatched readgroups (for pipeline use)."""
    ghosts = LIBRARY_IDS.values() - SPLIT_FILES.keys()
    for ghost_rg in ghosts:
        ghostfile = create_bamfile(ghost_rg, bam_header)
        SPLIT_FILES[ghost_rg] = ghostfile


def print_stats(ctr):
    headers = ["#seqs", "p7seq", "p7ind", "p5seq", "p5ind", "RG"]
    print(*headers, sep='\t')
    for key, count in ctr.most_common():
        print(count, key, sep='\t')


def main():
    """Main entrypoint into the 'splitbam' module."""

    # Variables maintained in the module scope
    global CFG, LIBRARY_IDS, SPLIT_FILES

    # Display CLI to get configuration from user
    CFG = get_config()

    # Proceed depending on whether --by-file or --by-readgroup specified
    if CFG.by_file:
        LIBRARY_IDS = parse_index(CFG.by_file)

    # Create a list of filters as instances of a GatedFilter subclasses.
    # Each is initiliased with a predicate based on config options passed
    # by the user on the command line.
    filters = [
        FilterLimit(CFG.limit),
        FilterQuality(CFG.minscore),
        FilterLength(CFG.minlength),
        FilterFlags(CFG.merged or CFG.mapped)
    ]

    # This is where we … (⌐■_■) … filter the filters
    active_filters = [f for f in filters if f.active]

    with AlignmentFile(CFG.bamfile, 'rb', check_sq=False) as bam:

        def main_loop():
            """Extracted main loop.

            Iterate over input BAM file and on each record:
            - apply active filters:-  apply_filters()
            - get readgroups:-        get_rg()
            - write to outputfile:-   writer()

            """
            hdr = bam.header
            for aln in apply_filters(active_filters, bam.fetch(until_eof=True)):
                if CFG.by_file:
                    idx_pair = get_indexpair(aln)
                    readgroup = idx_pair.readgroup
                    writer(aln, readgroup, hdr)
                    if not aln.is_read2:
                        yield idx_pair
                else:
                    readgroup = get_readgroup_by_tag(aln)
                    writer(aln, readgroup, hdr)
                    yield readgroup

        if CFG.stats:
            stats = Counter(main_loop())
            print_stats(stats)
        else:
            for _ in main_loop():
                pass

    # Register an exit hook to write empty BAM files for unmatched RGs.
    # This will trigger before cleanup_bamfiles() registered earlier (LIFO).
    if CFG.ghostfiles:
        atexit.register(create_ghost_files, bam.hdr)


if __name__ == '__main__':
    main()
