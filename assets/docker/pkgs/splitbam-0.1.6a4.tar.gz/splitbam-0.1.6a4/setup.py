from setuptools import setup

with open("README.md", "r") as fh:
    long_description = fh.read()

with open("splitbam/_version.py", 'r') as versionfile:
    exec(versionfile.read())

setup(
    name='splitbam',
    version=__version__,
    author='Johann Visagie',
    author_email='johann@visagie.za.net',
    url='https://vcs.eva.mpg.de/visagie/pysplitbam',
    license='MIT',
    packages=['splitbam'],
    package_data={'splitbam': ['data/*.json']},
    description='A command-line tool to split BAM files by read group',
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=['pysam'],
    python_requires='>=3.7',
    entry_points={'console_scripts': ['splitbam=splitbam.__main__:main']},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
