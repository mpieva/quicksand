# pysplitbam

Everyone writes a script to split BAM files. This one is mine.


## Why?

A Python tool that uses only commonly available Python modules is easy
to integrate into a [Snakemake](https://snakemake.readthedocs.io)
pipeline that utilises [Conda](https://conda.io) environments.


## About

This is an installable Python module called `pysplitbam`. It installs
an executable script called `splitbam`.

`splitbam` mirrors the functionality (almost) and the command-line
interface (almost) of Matthias Meyer's `splitBAM.pl`.


## Is it better than existing tools?

I wrote this tool primarily to ease integration into Snakemake pipelines,
as stated above. I therefore wrote it for straightforward simplicity and
clarity, **not** speed or features.

That said, in my tests I was pleasantly surprised at single-threaded
performance.


## What's missing?

* **Extensive testing!** I need to ensure that it gives the same output as
  existing tools under all circumstances.

* Currently it doesn't calculate the statistics that `splitBAM.pl` does.
  (I'm still considering about whether this is worth adding, since I don't
  need it for pipeline use.)

* Real time feedback to the user. Currently `splitbam` works silently without
  any output to the terminal.

* Some command-line options have yet to be implemented — these are marked
  with a `[*]` in the output of `splitbam --help`.

* Currently it only takes one BAM file as an argument, i.e. it doesn't
  automatically do a `samtools merge` on multiple input files. You can
  always do the `samtools merge` yourself and pipe the output to `splitbam`.


## What has been added?

* The ability to specify an output directory for the split files!

* The ability to set the compression level of the output BAM files. (This
  has a big impact on performance, and a moderate impact on disk usage.)

* The ability to write "orphan" (empty) BAM files for readgroups that
  have no sequences assigned. This is a hack to make the set of
  outputfiles predictable, and hence to make `splitbam` easier to
  integrate in pipelines.
  
* The ability to specify the standard list of sequencing indices at
  runtime. **[TODO]**


## Can't it go faster?

In theory, a lot. However, the curious and non-standard nature
of the `pysam` module makes this harder than it should be.
`pysam` is a Cython wrapper around the C++ library `htslib`.
This means that:

* `pysam` objects are not serialisable, making them hard to share
  between processes in Python's native multiprocessing environment.

* `pysam` objects can only address *actual* Python file objects
  as well as STDIN and STDOUT, and *not* other file-like objects,
  making it impossible to use optimisations like memory-mapped files.
   
If you have a smart idea to speed things up, let me know! :)

In short, making it significantly faster in Python would probably
require as much work as rewriting it in a language more suited to the
task. The latter is on my list of things to do … when I have time.


## Installation

These instructions are for UNIX-like systems (e.g. Linux and macOS).

### Requirements

* Python 3.7 or greater is required.

* The `pysam` module will automatically be installed as a dependency
  if you use either of the following installation methods.

* There are no other 3rd party dependencies.

### How to install…

> These instructions are for "everyone". If you're comfortable intalling a
> Python module, do it the way you normally would.

Download the wheel (binary distribution) file and install it using `pip3`.

Go to the project's [tags page](https://vcs.eva.mpg.de/visagie/pysplitbam/tags),
and download the wheel file from the latest published version which should
be at the top of the list. Place this `.whl` file somehwere convenient and run:

```bash
pip3 install splitbam-0.1.2-py3-none-any.whl
```

(Note that the version number in the filename will of course depend on the
version you downloaded and may differ from this example.)


## Usage

The executable script is called `splitbam`.
For help on the command-line interface, run:

```bash
$ splitbam --help
```

A very common, basic usage:

```bash
$ splitbam --by-file indices.txt input.bam
```


## Known bugs

* The `-l`/`--limit` flag does not work correctly and should currently be
  avoided. See Issue #1.

Other bugs are likely. Please report them as issues on [the
issues page](http://vcs.eva.mpg.de/visagie/pysplitbam/issues).
