use std::error::Error;
use rust_htslib::bam;
use rust_htslib::bam::Read;

mod cli;

fn main() {
    let config = cli::Config::new().expect("Error processing command line");
    filter_bam(config.cutoff, config.inputfile, config.outputfile).expect("Error filtering BAM")
}

fn filter_bam(cutoff: usize,
              mut reader: bam::Reader,
              mut writer: bam::Writer) -> Result<(), Box<dyn Error>> {
    let mut record = bam::Record::new();
    while let true = reader.read(&mut record)? {
        if record.seq().len() >= cutoff {
            writer.write(&record)?;
        }
    };
    Ok(())
}
