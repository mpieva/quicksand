use std::error::Error;

use clap::{App, Arg, ArgMatches, crate_version, crate_authors};
use rust_htslib::bam;
use rust_htslib::bam::Read;

pub struct Config {
    pub inputfile: bam::Reader,
    pub outputfile: bam::Writer,
    pub cutoff: usize,
}

impl Config {
    pub fn new() -> Result<Config, Box<dyn Error>> {
        let args = Self::parse_commandline();

        let compression_level = args.value_of("compression_level")
            .ok_or("error parsing command line parameters")?
            .parse::<u32>()?;
        let compression_threads = args.value_of("compression_threads")
            .ok_or("error parsing command line parameters")?
            .parse::<usize>()?;
        let cutoff = args.value_of("cutoff")
            .ok_or("error parsing command line parameters")?
            .parse::<usize>()?;

        let inputfile = match args.value_of("inputfile") {
            Some(filename) => bam::Reader::from_path(filename)?,
            None => bam::Reader::from_stdin()?,
        };

        let header = bam::Header::from_template(inputfile.header());

        let mut outputfile = match args.value_of("outputfile") {
            Some(filename) =>
                bam::Writer::from_path(filename, &header, bam::Format::BAM)?,
            None =>
                bam::Writer::from_stdout(&header, bam::Format::BAM)?,
        };

        outputfile.set_compression_level(bam::CompressionLevel::Level(compression_level))?;
        outputfile.set_threads(compression_threads)?;

        Ok(Config { inputfile, outputfile, cutoff })
    }

    fn parse_commandline() -> ArgMatches<'static> {
        let app = App::new("bam-lengthfilter")
            .version(crate_version!())
            .author(crate_authors!())
            .long_about("Filter BAM file by sequence length")
            .arg(Arg::with_name("cutoff")
                .short("c")
                .long("cutoff")
                .value_name("N")
                .help("Sequences shorter than cutoff will be filtered")
                .takes_value(true)
                .default_value("35")
            )
            .arg(Arg::with_name("outputfile")
                .short("o")
                .long("outputfile")
                .value_name("FILE")
                .help("Output BAM file [default: STDOUT]")
                .takes_value(true)
            )
            .arg(Arg::with_name("compression_level")
                .short("l")
                .long("level")
                .value_name("N")
                .help("BGZF compression level [0..9]")
                .takes_value(true)
                .possible_values(&["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"])
                .default_value("6")
                .hide_possible_values(true)
            )
            .arg(Arg::with_name("compression_threads")
                .short("j")
                .long("jobs")
                .value_name("N")
                .help("Compression threads")
                .takes_value(true)
                .default_value("4")
            )
            .arg(Arg::with_name("inputfile")
                .help("Input BAM file [default: STDIN]")
                .value_name("FILE")
                .index(1)
            );
        app.get_matches()
    }
}
